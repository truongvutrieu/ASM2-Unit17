import pandas as pd
import nltk
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, Dataset
from transformers import AdamW
nltk.download('punkt')

# Example feedback data to train model
data = {
    'feedback': [
        "The product quality is excellent.",
        "I am very satisfied with its performance.",
        "The shipping was delayed.",
        "Customer service was very helpful.",
        "The price is a bit high.",
        "The product arrived in perfect condition.",
        "The instructions were confusing.",
        "The packaging was very secure.",
        "I received the wrong item.",
        "The battery life is impressive.",
        "It stopped working after a week.",
        "The design is sleek and modern.",
        "The color did not match the description.",
        "It was easy to set up.",
        "The material feels cheap.",
        "The product exceeded my expectations.",
        "The delivery took too long.",
        "The customer support was unresponsive.",
        "I love the features it offers.",
        "The quality is not as good as advertised.",
        "The sound quality is fantastic.",
        "The product arrived damaged.",
        "The app integration is seamless.",
        "The price is reasonable for what you get.",
        "The product was missing parts.",
        "It performs better than expected.",
        "The product feels sturdy and well-made.",
        "The website is difficult to navigate.",
        "The product heats up quickly.",
        "The return process was a hassle.",
        "The customer service resolved my issue promptly.",
        "The product has a strong chemical smell.",
        "I am very happy with my purchase.",
        "The manual is not user-friendly.",
        "The product is very lightweight.",
        "The warranty is too short.",
        "The delivery was faster than expected.",
        "The product doesn't hold a charge.",
        "I would highly recommend this product.",
        "The packaging was damaged.",
        "The product works as described.",
        "The customer service was rude.",
        "I am impressed with the build quality.",
        "The product is overpriced.",
        "The functionality is exactly what I needed.",
        "The product broke after a month.",
        "The delivery was right on time.",
        "The product has a lot of useful features.",
        "The instructions are not clear.",
        "The product is worth every penny.",
        "The shipping cost is too high.",
        "The product looks great.",
        "The product arrived late.",
        "The quality is outstanding.",
        "The product didn't meet my expectations.",
        "I am thrilled with the purchase.",
        "The product feels flimsy.",
        "The setup was straightforward.",
        "The product has a poor finish.",
        "The customer service was fantastic.",
        "The product is not durable.",
        "The features are very innovative.",
        "The product is too complicated to use.",
        "I received excellent support.",
        "The product stopped working after a few uses.",
        "The design is very ergonomic.",
        "The product was not packaged well.",
        "I am very pleased with the quality.",
        "The product is too heavy.",
        "The price-performance ratio is great.",
        "The product arrived with scratches.",
        "The customer service went above and beyond.",
        "The product didn't turn on.",
        "The build quality is impressive.",
        "The product does not match the pictures.",
        "The delivery was extremely quick.",
        "The product is missing features.",
        "The product works perfectly.",
        "The price is too steep for what it offers.",
        "The product is exactly what I was looking for.",
        "The product feels very cheap.",
        "The quality of the product is superb.",
        "The product arrived broken.",
        "I am very satisfied with the purchase.",
        "The instructions are hard to follow.",
        "The product has excellent build quality.",
        "The customer service was not helpful.",
        "The delivery was quick and efficient.",
        "The product didn't last long.",
        "The setup was very easy.",
        "The product has an odd smell.",
        "The product meets all my needs.",
        "The product is very noisy.",
        "The customer support was excellent.",
        "The product was damaged on arrival.",
        "The design is very stylish.",
         "The customer support was excellent.",
        "The product was damaged on arrival.",
        "The design is very stylish.",
        "The product did not work as expected."
    ],
    'label': [
        1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
        0, 1, 0, 1, 0, 1, 0, 0, 1, 0,
        1, 0, 1, 1, 0, 1, 1, 0, 1, 0,
        1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
        1, 0, 1, 0, 1, 0, 1, 1, 0, 1,
        1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
        1, 0, 1, 0, 1, 0, 1, 1, 0, 1,
        0, 1, 0, 1, 0, 1, 1, 0, 1, 0,
        1, 0, 1, 0, 1, 0, 1, 0, 1, 0,
        1, 0, 1, 0, 1, 0, 1, 0, 1, 0
    ]
}



df = pd.DataFrame(data)

# Tokenize NLTK
df['tokens'] = df['feedback'].apply(nltk.word_tokenize)
print(df)
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, Dataset
from transformers import AdamW

# Load BERT Model & tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)

# Prepare data for BERT
class FeedbackDataset(Dataset):
    def __init__(self, feedbacks, labels, tokenizer, max_length):
        self.feedbacks = feedbacks
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.feedbacks)

    def __getitem__(self, idx):
        feedback = self.feedbacks[idx]
        label = self.labels[idx]

        encoding = self.tokenizer.encode_plus(
            feedback,
            add_special_tokens=True,
            max_length=self.max_length,
            return_token_type_ids=False,
            padding='max_length',
            return_attention_mask=True,
            return_tensors='pt',
        )

        return {
            'feedback_text': feedback,
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

MAX_LEN = 50
BATCH_SIZE = 2
dataset = FeedbackDataset(df['feedback'].tolist(), df['label'].tolist(), tokenizer, MAX_LEN)
dataloader = DataLoader(dataset, batch_size=BATCH_SIZE)

# Training loop (simple example)
optimizer = AdamW(model.parameters(), lr=1e-5)
model.train()

for epoch in range(3):  # Number of epochs
    for batch in dataloader:
        optimizer.zero_grad()
        input_ids = batch['input_ids']
        attention_mask = batch['attention_mask']
        labels = batch['labels']
        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        print(f'Epoch: {epoch}, Loss: {loss.item()}')

# Save the model
model.save_pretrained('bert-feedback-model')
tokenizer.save_pretrained('bert-feedback-tokenizer')
model.eval()

# Example feedback to predict
new_feedback = ["The product quality is excellent."]
encoding = tokenizer.encode_plus(
    new_feedback[0],
    add_special_tokens=True,
    max_length=MAX_LEN,
    return_token_type_ids=False,
    padding='max_length',
    return_attention_mask=True,
    return_tensors='pt',
)

input_ids = encoding['input_ids']
attention_mask = encoding['attention_mask']

with torch.no_grad():
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    logits = outputs.logits
    predicted_class = torch.argmax(logits, dim=1).item()

print(f'Customer Feedback: "{new_feedback[0]}", Predict: {"Positive" if predicted_class == 1 else "Negative"}')