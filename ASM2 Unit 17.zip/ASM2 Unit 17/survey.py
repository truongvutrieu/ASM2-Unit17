import pandas as pd
import numpy as np
from faker import Faker

fake = Faker()
num_records = 3000

genders = ['Male', 'Female', 'Other']
ages = ['Under 18', '18-24', '25-34', '35-44', '45-54', 'Over 55']
usage_durations = ['Less than 1 month', '1-6 months', '6-12 months', 'Over 1 year']
product_quality = ['Excellent', 'Good', 'Average', 'Poor', 'Very Poor']
service_quality = ['Excellent', 'Good', 'Average', 'Poor', 'Very Poor']
issues = ['Yes', 'No']
purchase_frequencies = ['Yes', 'No']
purchase_locations = ['Physical Store', 'Company Website', 'E-commerce Platforms', 'Distributor']
factors = ['Product Quality', 'Reasonable Price', 'Customer Service', 'Promotions and Discounts', 'Brand Reputation', 'Other']
feedback_quality = ['Excellent', 'Good', 'Average', 'Poor', 'Very Poor']
feedback_list = ['Yes', 'No']

data = {
    "Full Name": [fake.name() for _ in range(num_records)],
    "Email": [f"{fake.user_name()}@gmail.com" for _ in range(num_records)], 
    "Gender": np.random.choice(genders, size=num_records),
    "Age": np.random.choice(ages, size=num_records),
    "How long have you been using our products/services?": np.random.choice(usage_durations, size=num_records),
    "How would you rate the quality of our products?": np.random.choice(product_quality, size=num_records),
    "How would you rate our customer service?": np.random.choice(service_quality, size=num_records),
    "Have you experienced any issues with our products or services?": np.random.choice(issues, size=num_records),
    "If yes, please describe the issue in detail:": [fake.text(max_nb_chars=200) if issue == 'Yes' else '' for issue in np.random.choice(issues, size=num_records)],
    "Do you frequently purchase our products/services?": np.random.choice(purchase_frequencies, size=num_records),
    "Where do you usually buy our products/services from?": np.random.choice(purchase_locations, size=num_records),
    "What factors influence your decision to purchase our products/services? (Select all that apply)": [', '.join(np.random.choice(factors, size=np.random.randint(1, 4), replace=False)) for _ in range(num_records)],
    "Do you have any suggestions on how we can improve our products/services to increase sales?": [fake.text(max_nb_chars=200) for _ in range(num_records)],
    "Do you regularly provide feedback about our products/services?": np.random.choice(feedback_list, size=num_records),
    "How would you rate our process for receiving and handling feedback?": np.random.choice(feedback_quality, size=num_records),
    "Do you have any suggestions on how we can improve our feedback handling process?": [fake.text(max_nb_chars=200) for _ in range(num_records)],
    "Do you feel that we listen to and address your feedback in a timely and effective manner?": np.random.choice(feedback_list, size=num_records),
    "If no, please describe in detail how we can improve:": [fake.text(max_nb_chars=200) if response == 'No' else '' for response in np.random.choice(feedback_list, size=num_records)],
    "Do you have any other comments or suggestions on how we can enhance our sales and feedback services?": [fake.text(max_nb_chars=200) for _ in range(num_records)],
}

df = pd.DataFrame(data)

df.to_csv('customer_feedback.csv', index=False)

print("File customer_feedback.csv has been created successfully!")
